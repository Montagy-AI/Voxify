CREATE VIEW user_summary AS
SELECT 
    u.id,
    u.email,
    u.subscription_type,
    COUNT(DISTINCT vs.id) as voice_samples_count,
    COUNT(DISTINCT vm.id) as models_count,
    COUNT(DISTINCT sj.id) as synthesis_jobs_count,
    u.storage_used_bytes,
    u.created_at,
    u.last_login_at
FROM users u
LEFT JOIN voice_samples vs ON u.id = vs.user_id AND vs.status = 'ready'
LEFT JOIN voice_models vm ON vs.id = vm.voice_sample_id AND vm.is_active = TRUE
LEFT JOIN synthesis_jobs sj ON u.id = sj.user_id AND sj.status = 'completed'
GROUP BY u.id;

