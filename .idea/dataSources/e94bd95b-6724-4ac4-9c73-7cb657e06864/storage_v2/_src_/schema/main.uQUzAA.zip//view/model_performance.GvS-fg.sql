CREATE VIEW model_performance AS
SELECT 
    vm.id,
    vm.name,
    vm.voice_sample_id,
    vm.training_status,
    vm.quality_metrics,
    vm.similarity_score,
    COUNT(sj.id) as usage_count,
    AVG(sj.processing_time_ms) as avg_processing_time,
    vm.created_at
FROM voice_models vm
LEFT JOIN synthesis_jobs sj ON vm.id = sj.voice_model_id AND sj.status = 'completed'
WHERE vm.is_active = TRUE
GROUP BY vm.id;

