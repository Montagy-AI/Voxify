CREATE TRIGGER update_voice_models_timestamp 
    AFTER UPDATE ON voice_models
    FOR EACH ROW
    WHEN NEW.updated_at = OLD.updated_at
BEGIN
    UPDATE voice_models SET updated_at = CURRENT_TIMESTAMP WHERE id = NEW.id;
END;

