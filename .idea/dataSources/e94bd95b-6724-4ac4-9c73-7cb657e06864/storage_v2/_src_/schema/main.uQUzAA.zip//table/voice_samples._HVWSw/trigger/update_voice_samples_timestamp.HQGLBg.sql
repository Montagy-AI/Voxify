CREATE TRIGGER update_voice_samples_timestamp 
    AFTER UPDATE ON voice_samples
    FOR EACH ROW
    WHEN NEW.updated_at = OLD.updated_at
BEGIN
    UPDATE voice_samples SET updated_at = CURRENT_TIMESTAMP WHERE id = NEW.id;
END;

