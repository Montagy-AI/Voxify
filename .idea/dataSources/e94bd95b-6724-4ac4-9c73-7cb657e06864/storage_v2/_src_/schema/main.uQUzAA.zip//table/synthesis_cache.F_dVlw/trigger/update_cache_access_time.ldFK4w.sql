CREATE TRIGGER update_cache_access_time
    AFTER UPDATE ON synthesis_cache
    FOR EACH ROW
    WHEN NEW.hit_count > OLD.hit_count
BEGIN
    UPDATE synthesis_cache SET last_accessed = CURRENT_TIMESTAMP WHERE id = NEW.id;
END;

